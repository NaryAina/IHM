import Rasterizer
Rasterizer.showMouse(0)

