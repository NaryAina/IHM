def computeSpeed(valueGSR) :

    #print(valueGSR)

    if valueGSR >= 2 :
        return valueGSR / 100 - 0.01
    else :
        return 0.01