import Rasterizer
Rasterizer.showMouse(1)