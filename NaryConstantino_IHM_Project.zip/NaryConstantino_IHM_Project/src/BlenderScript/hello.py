"""  
def main():

    print("Hello, World!")


main()

from bge import logic as gl
print(gl.truc)
"""

from bge import logic as gl
print(gl.globalDict["modeChallenge"])